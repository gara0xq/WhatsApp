import 'package:get/get.dart';
import '../../src/presentation/providers/home_provider.dart';
import '../../src/presentation/providers/welcome_provider.dart';

import '../../src/presentation/providers/auth_provider.dart';

class GetBindings extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AuthProvider>(() => AuthProvider());
    Get.lazyPut<WelcomeProvider>(() => WelcomeProvider(), fenix: true);
  }
}
