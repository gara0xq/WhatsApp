import 'dart:async';

import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:whatsapp/src/presentation/screens/home_screen.dart';
import '../../data/repositories/welcome_repository_impl.dart';
import '../../domain/usecases/welcome/get_user_prefs_use_case.dart';
import '../../domain/usecases/welcome/set_user_prefs_use_case.dart';
import 'home_provider.dart';

class WelcomeProvider extends GetxController {
  SetUserPrefsUseCase _setUserPrefsUseCase;
  GetUserPrefsUseCase _getUserPrefsUseCase;
  late SharedPreferences prefs;
  String currentUserId = "";
  initPrefs() async {
    prefs = await SharedPreferences.getInstance();
  }

  WelcomeProvider()
      : _getUserPrefsUseCase = GetUserPrefsUseCase(WelcomeRepositoryImpl()),
        _setUserPrefsUseCase = SetUserPrefsUseCase(WelcomeRepositoryImpl());

  setUser(String userId) {
    _setUserPrefsUseCase(prefs, userId);
  }

  getUser() {
    currentUserId = _getUserPrefsUseCase(prefs);
  }

  @override
  void onInit() async {
    await initPrefs();
    getUser();

    Get.lazyPut(() => HomeProvider(currentUserId));
    Get.find<HomeProvider>();
    if (currentUserId != "") {
      Timer(
        Duration(seconds: 10),
        () => Get.offAll(
          HomeScreen(
            userId: currentUserId,
          ),
        ),
      );
    } else {
      Get.offAllNamed('/welcome');
    }
    super.onInit();
  }
}
