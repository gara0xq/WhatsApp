import 'package:shared_preferences/shared_preferences.dart';
import 'package:whatsapp/src/domain/repositories/welcome_repository.dart';

class GetUserPrefsUseCase {
  final WelcomeRepository _welcomeRepository;

  GetUserPrefsUseCase(this._welcomeRepository);

  String call(SharedPreferences prefs) {
    return _welcomeRepository.getUser(prefs);
  }
}
